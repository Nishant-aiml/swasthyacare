import React, { useState, useEffect } from 'react';
import { Search, Filter, AlertCircle, Pill, Building2, IndianRupee, ExternalLink, Heart } from 'lucide-react';
import { useQuery } from 'react-query';
import { Medicine } from '../types';

// In a real app, this would come from an API
const fetchMedicines = async (query: string): Promise<Medicine[]> => {
  // Simulated API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return [
    {
      id: '1',
      brandName: 'Crocin Advance',
      genericName: 'Paracetamol',
      price: 49.99,
      manufacturer: 'GSK Pharmaceuticals',
      dosageForm: 'Tablet',
      strength: '500mg',
      availableAt: ['Apollo Pharmacy', 'MedPlus'],
      interactions: ['Warfarin', 'Alcohol'],
      sideEffects: ['Nausea', 'Skin rash', 'Liver damage (rare)'],
      usageInstructions: 'Take 1-2 tablets every 4-6 hours as needed',
      requiresPrescription: false,
      alternatives: [
        {
          id: 'a1',
          name: 'Dolo 650',
          price: 30.50,
          manufacturer: 'Micro Labs Ltd',
          savingsPercentage: 39,
          qualityScore: 4.8
        },
        {
          id: 'a2',
          name: 'Paracip 500',
          price: 25.75,
          manufacturer: 'Cipla Ltd',
          savingsPercentage: 48,
          qualityScore: 4.7
        }
      ]
    },
    {
      id: '2',
      brandName: 'Allegra 120mg',
      genericName: 'Fexofenadine',
      price: 165.00,
      manufacturer: 'Sanofi India',
      dosageForm: 'Tablet',
      strength: '120mg',
      availableAt: ['Apollo Pharmacy', 'MedPlus', 'Wellness Forever'],
      interactions: ['Antacids', 'Fruit juices'],
      sideEffects: ['Headache', 'Drowsiness', 'Nausea'],
      usageInstructions: 'Take 1 tablet daily',
      requiresPrescription: true,
      alternatives: [
        {
          id: 'b1',
          name: 'Fexova 120',
          price: 120.00,
          manufacturer: 'Cipla Ltd',
          savingsPercentage: 27,
          qualityScore: 4.6
        }
      ]
    }
  ].filter(med => 
    med.brandName.toLowerCase().includes(query.toLowerCase()) ||
    med.genericName.toLowerCase().includes(query.toLowerCase()) ||
    med.manufacturer.toLowerCase().includes(query.toLowerCase())
  );
};

export default function Medicines() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [filters, setFilters] = useState({
    requiresPrescription: false,
    hasAlternatives: false,
    priceRange: [0, 1000]
  });

  const { data: medicines = [], isLoading, error } = useQuery(
    ['medicines', searchQuery],
    () => fetchMedicines(searchQuery),
    { keepPreviousData: true }
  );

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Search and Filters */}
        <div className="lg:w-80 flex-shrink-0 space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearch}
                placeholder="Search medicines..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>

            <div className="mt-4 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500" />
                Filters
              </h3>

              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={filters.requiresPrescription}
                    onChange={(e) => setFilters(f => ({ ...f, requiresPrescription: e.target.checked }))}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-sm">Prescription Required</span>
                </label>

                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={filters.hasAlternatives}
                    onChange={(e) => setFilters(f => ({ ...f, hasAlternatives: e.target.checked }))}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-sm">Has Alternatives</span>
                </label>

                <div className="space-y-1">
                  <label className="text-sm font-medium">Price Range</label>
                  <input
                    type="range"
                    min="0"
                    max="1000"
                    value={filters.priceRange[1]}
                    onChange={(e) => setFilters(f => ({ ...f, priceRange: [0, parseInt(e.target.value)] }))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>₹0</span>
                    <span>₹{filters.priceRange[1]}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Medicine List */}
        <div className="flex-1">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
            </div>
          ) : error ? (
            <div className="bg-red-50 text-red-700 p-4 rounded-lg flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              <span>Failed to load medicines</span>
            </div>
          ) : medicines.length === 0 ? (
            <div className="bg-gray-50 text-gray-600 p-8 rounded-lg text-center">
              <Pill className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p>No medicines found matching your search</p>
            </div>
          ) : (
            <div className="grid gap-6">
              {medicines.map((medicine) => (
                <div
                  key={medicine.id}
                  className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h2 className="text-xl font-semibold flex items-center gap-2">
                        {medicine.brandName}
                        {medicine.requiresPrescription && (
                          <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full">
                            Prescription Required
                          </span>
                        )}
                      </h2>
                      <p className="text-gray-600">{medicine.genericName}</p>
                      <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                        <Building2 className="h-4 w-4" />
                        {medicine.manufacturer}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-lg font-semibold text-emerald-600 flex items-center">
                        <IndianRupee className="h-4 w-4" />
                        {medicine.price}
                      </div>
                      <button
                        onClick={() => setSelectedMedicine(medicine)}
                        className="text-emerald-600 hover:text-emerald-700"
                      >
                        <ExternalLink className="h-5 w-5" />
                      </button>
                    </div>
                  </div>

                  {medicine.alternatives && medicine.alternatives.length > 0 && (
                    <div className="mt-4">
                      <h3 className="text-sm font-medium text-gray-700 mb-2">Generic Alternatives</h3>
                      <div className="grid gap-2">
                        {medicine.alternatives.map((alt) => (
                          <div
                            key={alt.id}
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                          >
                            <div>
                              <p className="font-medium">{alt.name}</p>
                              <p className="text-sm text-gray-600">{alt.manufacturer}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-emerald-600 font-medium">₹{alt.price}</p>
                              <p className="text-sm text-emerald-700">Save {alt.savingsPercentage}%</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="mt-4 flex flex-wrap gap-2">
                    {medicine.availableAt.map((store) => (
                      <span
                        key={store}
                        className="text-sm bg-gray-50 text-gray-700 px-3 py-1 rounded-full"
                      >
                        {store}
                      </span>
                    ))}
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <button className="flex items-center justify-center gap-2 bg-emerald-600 text-white py-2 rounded-lg hover:bg-emerald-700">
                      <Pill className="h-4 w-4" />
                      View Details
                    </button>
                    <button className="flex items-center justify-center gap-2 border border-emerald-600 text-emerald-600 py-2 rounded-lg hover:bg-emerald-50">
                      <Heart className="h-4 w-4" />
                      Save
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}