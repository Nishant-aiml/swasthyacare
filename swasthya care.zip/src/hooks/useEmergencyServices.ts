import { create } from 'zustand';
import { EmergencyService } from '../types';

interface EmergencyServicesState {
  services: EmergencyService[];
  loading: boolean;
  error: string | null;
  selectedService: EmergencyService | null;
  filters: {
    type: 'all' | 'hospital' | 'pharmacy' | 'ambulance';
    open24Hours: boolean;
    acceptsInsurance: boolean;
  };
  setFilters: (filters: Partial<EmergencyServicesState['filters']>) => void;
  fetchNearbyServices: (coordinates: [number, number]) => Promise<void>;
  selectService: (service: EmergencyService | null) => void;
}

export const useEmergencyServices = create<EmergencyServicesState>((set) => ({
  services: [],
  loading: false,
  error: null,
  selectedService: null,
  filters: {
    type: 'all',
    open24Hours: false,
    acceptsInsurance: false,
  },

  setFilters: (newFilters) => {
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    }));
  },

  fetchNearbyServices: async (coordinates) => {
    set({ loading: true, error: null });
    try {
      // Simulate API call with mock data
      // In a real app, this would be an API call to your backend
      await new Promise(resolve => setTimeout(resolve, 1000));

      const mockServices: EmergencyService[] = [
        {
          id: '1',
          name: 'Apollo Hospital',
          type: 'hospital',
          location: {
            lat: coordinates[1] + 0.01,
            lng: coordinates[0] + 0.01,
            address: 'Film Nagar, Hyderabad'
          },
          phone: '+91-9876543210',
          isOpen24Hours: true,
          emergencyServices: ['ICU', 'Trauma Care', 'Emergency Surgery'],
          acceptedInsurance: ['Apollo Health', 'Star Health', 'LIC'],
          ratings: {
            average: 4.8,
            count: 1250
          }
        },
        {
          id: '2',
          name: 'LifeLine Ambulance',
          type: 'ambulance',
          location: {
            lat: coordinates[1] - 0.01,
            lng: coordinates[0] - 0.01,
            address: 'Mobile Unit'
          },
          phone: '108',
          isOpen24Hours: true,
          emergencyServices: ['Advanced Life Support', 'Basic Life Support'],
          ratings: {
            average: 4.6,
            count: 850
          }
        },
        {
          id: '3',
          name: 'MedPlus Pharmacy',
          type: 'pharmacy',
          location: {
            lat: coordinates[1] + 0.005,
            lng: coordinates[0] - 0.005,
            address: 'Jubilee Hills, Hyderabad'
          },
          phone: '+91-9876543211',
          isOpen24Hours: true,
          emergencyServices: ['24/7 Medicine Delivery', 'Emergency Supplies'],
          acceptedInsurance: ['Apollo Health', 'Star Health'],
          ratings: {
            average: 4.5,
            count: 980
          }
        },
        {
          id: '4',
          name: 'KIMS Hospital',
          type: 'hospital',
          location: {
            lat: coordinates[1] - 0.008,
            lng: coordinates[0] + 0.008,
            address: 'Secunderabad, Hyderabad'
          },
          phone: '+91-9876543212',
          isOpen24Hours: true,
          emergencyServices: ['Emergency Room', 'Critical Care', 'Pediatric Emergency'],
          acceptedInsurance: ['Star Health', 'KIMS Health', 'LIC'],
          ratings: {
            average: 4.7,
            count: 1100
          }
        }
      ];

      set({ services: mockServices, loading: false });
    } catch (error) {
      set({ 
        error: error instanceof Error ? error.message : 'Failed to fetch services',
        loading: false 
      });
    }
  },

  selectService: (service) => {
    set({ selectedService: service });
  },
}));