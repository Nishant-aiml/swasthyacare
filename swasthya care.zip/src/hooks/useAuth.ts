import { create } from 'zustand';

interface User {
  id: string;
  email: string;
  name: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  signup: (data: { email: string; password: string; name: string }) => Promise<void>;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,

  login: async (credentials) => {
    try {
      // In a real app, this would make an API call
      const mockUser = {
        id: '123',
        email: credentials.email,
        name: 'Test User',
      };

      set({ user: mockUser, isAuthenticated: true });
    } catch (error) {
      throw new Error('Invalid credentials');
    }
  },

  signup: async (data) => {
    try {
      // In a real app, this would make an API call
      const mockUser = {
        id: '123',
        email: data.email,
        name: data.name,
      };

      set({ user: mockUser, isAuthenticated: true });
    } catch (error) {
      throw new Error('Registration failed');
    }
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
}));