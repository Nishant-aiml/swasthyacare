import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import Header from './components/Header';
import EmergencyCard from './components/EmergencyCard';
import HealthAIChat from './components/HealthAIChat';
import LocationMap from './components/EmergencyLocation/LocationMap';
import RecordsList from './components/HealthRecords/RecordsList';
import Medicines from './pages/Medicines';
import DoctorConsultation from './pages/DoctorConsultation';
import LoginForm from './components/Auth/LoginForm';
import ProfileSetup from './components/Profile/ProfileSetup';
import LanguageSelector from './components/LanguageSelector';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
}

function Home() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <EmergencyCard />
        <LocationMap />
        <RecordsList />
      </div>
      <div className="lg:col-span-1">
        <HealthAIChat />
      </div>
    </div>
  );
}

export default function App() {
  const { isAuthenticated } = useAuth();

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {isAuthenticated && <Header />}
        <div className="fixed bottom-4 right-4 z-50">
          <LanguageSelector />
        </div>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/login" element={<LoginForm />} />
            <Route
              path="/profile/setup"
              element={
                <PrivateRoute>
                  <ProfileSetup />
                </PrivateRoute>
              }
            />
            <Route
              path="/"
              element={
                <PrivateRoute>
                  <Home />
                </PrivateRoute>
              }
            />
            <Route
              path="/medicines"
              element={
                <PrivateRoute>
                  <Medicines />
                </PrivateRoute>
              }
            />
            <Route
              path="/doctors"
              element={
                <PrivateRoute>
                  <DoctorConsultation />
                </PrivateRoute>
              }
            />
          </Routes>
        </main>
      </div>
    </Router>
  );
}