import React from 'react';
import { Pill, IndianRupee, Store } from 'lucide-react';

interface MedicineCardProps {
  medicine: {
    brandName: string;
    genericName: string;
    price: number;
    manufacturer: string;
    alternatives: { name: string; price: number }[];
  };
}

export default function MedicineCard({ medicine }: MedicineCardProps) {
  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-semibold text-lg">{medicine.brandName}</h3>
          <p className="text-gray-600 text-sm">{medicine.genericName}</p>
          <p className="text-gray-500 text-sm mt-1">{medicine.manufacturer}</p>
        </div>
        <div className="flex items-center text-emerald-600 font-semibold">
          <IndianRupee className="h-4 w-4" />
          <span>{medicine.price}</span>
        </div>
      </div>
      
      <div className="mt-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Generic Alternatives</h4>
        <div className="space-y-2">
          {medicine.alternatives.map((alt, index) => (
            <div key={index} className="flex items-center justify-between text-sm bg-gray-50 p-2 rounded">
              <span>{alt.name}</span>
              <span className="text-emerald-600 font-medium">₹{alt.price}</span>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-4 flex gap-2">
        <button className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 text-white py-2 rounded hover:bg-emerald-700">
          <Store className="h-4 w-4" />
          Find Nearby
        </button>
        <button className="flex-1 flex items-center justify-center gap-2 border border-emerald-600 text-emerald-600 py-2 rounded hover:bg-emerald-50">
          <Pill className="h-4 w-4" />
          View Details
        </button>
      </div>
    </div>
  );
}