import React, { useState } from 'react';
import { Send, Bot, PlusCircle } from 'lucide-react';
import ChatMessage from './HealthAIChat/ChatMessage';
import SymptomChecker from './HealthAIChat/SymptomChecker';

export default function HealthAIChat() {
  const [message, setMessage] = useState('');
  const [showSymptomChecker, setShowSymptomChecker] = useState(false);
  const [messages, setMessages] = useState([
    {
      type: 'bot' as const,
      content: "Hello! I'm your personal health assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ]);

  const handleSend = () => {
    if (!message.trim()) return;

    setMessages(prev => [
      ...prev,
      {
        type: 'user' as const,
        content: message,
        timestamp: new Date(),
      },
    ]);
    setMessage('');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 h-[600px] flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bot className="h-6 w-6 text-emerald-600" />
            <h2 className="text-lg font-semibold">SwasthyaAI Assistant</h2>
          </div>
          <button
            onClick={() => setShowSymptomChecker(!showSymptomChecker)}
            className="text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
          >
            <PlusCircle className="h-5 w-5" />
            <span>Check Symptoms</span>
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {showSymptomChecker && <SymptomChecker />}
        {messages.map((msg, index) => (
          <ChatMessage key={index} message={msg} />
        ))}
      </div>

      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your health concern..."
            className="flex-1 rounded-full border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            onClick={handleSend}
            className="bg-emerald-600 text-white rounded-full p-2 hover:bg-emerald-700"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
}