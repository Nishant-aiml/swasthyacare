import React from 'react';
import { Bot, User, AlertTriangle, Pill, Phone } from 'lucide-react';
import { AIResponse, Medicine } from '../../types';

interface ChatMessageProps {
  message: {
    type: 'user' | 'bot';
    content: string;
    timestamp: Date;
    aiResponse?: AIResponse;
  };
  onEmergencyCall?: () => void;
  onMedicineSelect?: (medicine: Medicine) => void;
}

export default function ChatMessage({ message, onEmergencyCall, onMedicineSelect }: ChatMessageProps) {
  const isBot = message.type === 'bot';
  const isEmergency = message.aiResponse?.type === 'emergency';
  
  return (
    <div className={`flex items-start space-x-2 ${isBot ? '' : 'flex-row-reverse space-x-reverse'}`}>
      <div className={`flex-shrink-0 rounded-full p-2 ${
        isBot ? 'bg-emerald-100' : 'bg-blue-100'
      }`}>
        {isBot ? (
          <Bot className="h-5 w-5 text-emerald-600" />
        ) : (
          <User className="h-5 w-5 text-blue-600" />
        )}
      </div>
      
      <div className={`rounded-lg p-4 max-w-[80%] ${
        isBot ? 'bg-emerald-50' : 'bg-blue-50'
      }`}>
        <p className="text-sm">{message.content}</p>
        
        {message.aiResponse && (
          <div className="mt-3 space-y-3">
            {isEmergency && (
              <div className="bg-red-100 text-red-800 p-3 rounded-md flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                <span className="font-medium">Emergency Situation Detected</span>
              </div>
            )}
            
            {message.aiResponse.recommendations?.length > 0 && (
              <div className="space-y-2">
                <p className="font-medium text-sm">Recommendations:</p>
                <ul className="list-disc list-inside text-sm space-y-1">
                  {message.aiResponse.recommendations.map((rec, index) => (
                    <li key={index}>{rec}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {message.aiResponse.suggestedMedications && (
              <div className="space-y-2">
                <p className="font-medium text-sm">Suggested Medications:</p>
                <div className="grid gap-2">
                  {message.aiResponse.suggestedMedications.map((med) => (
                    <button
                      key={med.id}
                      onClick={() => onMedicineSelect?.(med)}
                      className="flex items-center justify-between p-2 bg-white rounded-md hover:bg-gray-50 border border-gray-200"
                    >
                      <div className="flex items-center gap-2">
                        <Pill className="h-4 w-4 text-emerald-600" />
                        <span>{med.brandName}</span>
                      </div>
                      <span className="text-sm text-gray-500">₹{med.price}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {isEmergency && onEmergencyCall && (
              <button
                onClick={onEmergencyCall}
                className="w-full bg-red-600 text-white py-2 rounded-md hover:bg-red-700 flex items-center justify-center gap-2"
              >
                <Phone className="h-4 w-4" />
                Call Emergency Services
              </button>
            )}
          </div>
        )}
        
        <span className="text-xs text-gray-500 mt-2 block">
          {message.timestamp.toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
}