import React from 'react';
import { Clock, CreditCard } from 'lucide-react';
import { useEmergencyServices } from '../../hooks/useEmergencyServices';

export default function ServiceFilters() {
  const { filters, setFilters } = useEmergencyServices();

  return (
    <div className="flex flex-wrap gap-2 p-4 bg-white border-b border-gray-200">
      <select
        value={filters.type}
        onChange={(e) => setFilters({ type: e.target.value as any })}
        className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500"
      >
        <option value="all">All Services</option>
        <option value="hospital">Hospitals</option>
        <option value="pharmacy">Pharmacies</option>
        <option value="ambulance">Ambulances</option>
      </select>

      <button
        onClick={() => setFilters({ open24Hours: !filters.open24Hours })}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm border
          ${filters.open24Hours
            ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
            : 'border-gray-300 hover:bg-gray-50'
          }`}
      >
        <Clock className="h-4 w-4" />
        24/7 Only
      </button>

      <button
        onClick={() => setFilters({ acceptsInsurance: !filters.acceptsInsurance })}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm border
          ${filters.acceptsInsurance
            ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
            : 'border-gray-300 hover:bg-gray-50'
          }`}
      >
        <CreditCard className="h-4 w-4" />
        Accepts Insurance
      </button>
    </div>
  );
}