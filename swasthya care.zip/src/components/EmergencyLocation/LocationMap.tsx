import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import MapboxGeocoder from '@mapbox/mapbox-gl-geocoder';
import '@mapbox/mapbox-gl-geocoder/dist/mapbox-gl-geocoder.css';
import { useEmergencyServices } from '../../hooks/useEmergencyServices';
import ServiceFilters from './ServiceFilters';
import ServiceDetails from './ServiceDetails';
import ServiceList from './ServiceList';
import { Building2, Ambulance, PillIcon, AlertCircle, Navigation, MapPin } from 'lucide-react';
import { EmergencyService } from '../../types';

const typeIcons = {
  hospital: Building2,
  ambulance: Ambulance,
  pharmacy: PillIcon,
};

const typeColors = {
  hospital: '#DC2626',
  ambulance: '#059669',
  pharmacy: '#2563EB',
};

export default function LocationMap() {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [address, setAddress] = useState<string>('');
  const { services, loading, error, fetchNearbyServices, selectedService, selectService } = useEmergencyServices();

  useEffect(() => {
    // Get user's location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords: [number, number] = [
            position.coords.longitude,
            position.coords.latitude
          ];
          setUserLocation(coords);
          fetchNearbyServices(coords);
          
          // Reverse geocode to get address
          fetch(`https://api.geoapify.com/v1/geocode/reverse?lat=${coords[1]}&lon=${coords[0]}&apiKey=YOUR_GEOAPIFY_KEY`)
            .then(res => res.json())
            .then(data => {
              if (data.features?.[0]?.properties) {
                const props = data.features[0].properties;
                setAddress(`${props.street || ''} ${props.city || ''} ${props.state || ''}`);
              }
            })
            .catch(() => {
              // Fallback to coordinates if geocoding fails
              setAddress(`${coords[1].toFixed(4)}, ${coords[0].toFixed(4)}`);
            });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, [fetchNearbyServices]);

  const handleServiceSelect = (service: EmergencyService) => {
    selectService(service);
  };

  const handleGetDirections = () => {
    if (!selectedService || !userLocation) return;
    
    const url = `https://www.google.com/maps/dir/?api=1&origin=${userLocation[1]},${userLocation[0]}&destination=${selectedService.location.lat},${selectedService.location.lng}`;
    window.open(url, '_blank');
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <ServiceFilters />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 h-[600px]">
        <div className="lg:col-span-2 relative">
          <div className="absolute inset-0 bg-gray-50 p-6">
            <div className="h-full flex flex-col">
              <div className="bg-white p-4 rounded-lg shadow-sm mb-4">
                <div className="flex items-center gap-3 mb-4">
                  <MapPin className="h-5 w-5 text-emerald-600" />
                  <div>
                    <h3 className="font-medium">Your Location</h3>
                    <p className="text-sm text-gray-600">{address || 'Detecting location...'}</p>
                  </div>
                </div>

                <div className="grid gap-4">
                  {services.map((service) => {
                    const Icon = typeIcons[service.type as keyof typeof typeIcons];
                    return (
                      <div
                        key={service.id}
                        className={`p-4 rounded-lg border transition-colors cursor-pointer
                          ${selectedService?.id === service.id 
                            ? 'border-emerald-500 bg-emerald-50' 
                            : 'border-gray-200 hover:border-emerald-500'
                          }`}
                        onClick={() => handleServiceSelect(service)}
                      >
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-full" style={{ backgroundColor: `${typeColors[service.type as keyof typeof typeColors]}20` }}>
                            <Icon className="h-5 w-5" style={{ color: typeColors[service.type as keyof typeof typeColors] }} />
                          </div>
                          <div>
                            <h4 className="font-medium">{service.name}</h4>
                            <p className="text-sm text-gray-600">{service.location.address}</p>
                            {service.isOpen24Hours && (
                              <span className="inline-block mt-1 text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                                Open 24/7
                              </span>
                            )}
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleGetDirections();
                            }}
                            className="ml-auto p-2 hover:bg-gray-100 rounded-full"
                          >
                            <Navigation className="h-5 w-5 text-gray-500" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          
          {loading && (
            <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
            </div>
          )}
        </div>
        
        <div className="p-4 border-l border-gray-200 overflow-y-auto">
          {error ? (
            <div className="text-center p-4">
              <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <p className="text-gray-600">{error}</p>
            </div>
          ) : selectedService ? (
            <ServiceDetails
              service={selectedService}
              userLocation={userLocation}
              onGetDirections={handleGetDirections}
              onClose={() => selectService(null)}
            />
          ) : (
            <ServiceList
              services={services}
              onServiceSelect={handleServiceSelect}
            />
          )}
        </div>
      </div>
    </div>
  );
}