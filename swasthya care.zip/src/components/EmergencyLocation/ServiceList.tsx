import React from 'react';
import { Building2, Ambulance, PillIcon, Clock, CreditCard, Navigation } from 'lucide-react';
import { EmergencyService } from '../../types';

interface ServiceListProps {
  services: EmergencyService[];
  onServiceSelect: (service: EmergencyService) => void;
}

const typeIcons = {
  hospital: Building2,
  ambulance: Ambulance,
  pharmacy: PillIcon,
};

export default function ServiceList({ services, onServiceSelect }: ServiceListProps) {
  return (
    <div className="space-y-4">
      <h3 className="font-medium text-lg">Nearby Emergency Services</h3>
      
      {services.length === 0 ? (
        <p className="text-gray-500 text-sm">No services found in this area</p>
      ) : (
        <div className="space-y-3">
          {services.map((service) => {
            const IconComponent = typeIcons[service.type as keyof typeof typeIcons] || Building2;
            
            return (
              <button
                key={service.id}
                onClick={() => onServiceSelect(service)}
                className="w-full text-left p-3 rounded-lg border border-gray-200 hover:border-emerald-500 hover:shadow-sm transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-full bg-emerald-50">
                    <IconComponent className="h-5 w-5 text-emerald-600" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium truncate">{service.name}</h4>
                    <p className="text-sm text-gray-600 truncate">{service.location.address}</p>
                    
                    <div className="flex flex-wrap gap-2 mt-2">
                      {service.isOpen24Hours && (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-blue-50 text-blue-700 text-xs">
                          <Clock className="h-3 w-3" />
                          24/7
                        </span>
                      )}
                      {service.acceptedInsurance && service.acceptedInsurance.length > 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-purple-50 text-purple-700 text-xs">
                          <CreditCard className="h-3 w-3" />
                          Insurance
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <Navigation className="h-4 w-4 text-gray-400" />
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}