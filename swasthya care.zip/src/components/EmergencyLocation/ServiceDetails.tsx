import React from 'react';
import { Phone, Navigation, Star, Clock, CreditCard, AlertCircle, X } from 'lucide-react';
import { EmergencyService } from '../../types';
import { useEmergencyContacts } from '../../hooks/useEmergencyContacts';

interface ServiceDetailsProps {
  service: EmergencyService;
  userLocation: [number, number] | null;
  onGetDirections: () => void;
  onClose: () => void;
}

export default function ServiceDetails({
  service,
  userLocation,
  onGetDirections,
  onClose
}: ServiceDetailsProps) {
  const { notifyContacts } = useEmergencyContacts();

  const handleEmergencyCall = () => {
    window.location.href = `tel:${service.phone}`;
  };

  const handleNotifyContacts = async () => {
    if (!userLocation) return;
    
    try {
      await notifyContacts({
        userId: 'current-user-id',
        serviceId: service.id,
        serviceName: service.name,
        location: userLocation,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Failed to notify contacts:', error);
    }
  };

  return (
    <div className="bg-white rounded-lg">
      <div className="p-4 border-b border-gray-200">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold">{service.name}</h3>
            <p className="text-gray-600">{service.location.address}</p>
          </div>
          <div className="flex items-center gap-2">
            {service.ratings && (
              <div className="flex items-center gap-1 bg-emerald-50 text-emerald-700 px-2 py-1 rounded">
                <Star className="h-4 w-4" />
                <span>{service.ratings.average}</span>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full"
            >
              <X className="h-5 w-5 text-gray-500" />
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {service.isOpen24Hours && (
            <span className="flex items-center gap-1 text-sm bg-blue-50 text-blue-700 px-2 py-1 rounded">
              <Clock className="h-4 w-4" />
              Open 24/7
            </span>
          )}
          {service.acceptedInsurance && service.acceptedInsurance.length > 0 && (
            <span className="flex items-center gap-1 text-sm bg-purple-50 text-purple-700 px-2 py-1 rounded">
              <CreditCard className="h-4 w-4" />
              Insurance Accepted
            </span>
          )}
        </div>
      </div>

      {service.emergencyServices && (
        <div className="p-4 border-b border-gray-200">
          <h4 className="font-medium mb-2">Available Emergency Services</h4>
          <div className="grid grid-cols-2 gap-2">
            {service.emergencyServices.map((es, index) => (
              <span
                key={index}
                className="text-sm bg-gray-50 text-gray-700 px-2 py-1 rounded"
              >
                {es}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className="p-4 space-y-2">
        <button
          onClick={handleEmergencyCall}
          className="w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 flex items-center justify-center gap-2"
        >
          <Phone className="h-4 w-4" />
          Call Now
        </button>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={onGetDirections}
            className="flex items-center justify-center gap-2 bg-emerald-600 text-white py-2 px-4 rounded-lg hover:bg-emerald-700"
          >
            <Navigation className="h-4 w-4" />
            Get Directions
          </button>

          <button
            onClick={handleNotifyContacts}
            className="flex items-center justify-center gap-2 border border-emerald-600 text-emerald-600 py-2 px-4 rounded-lg hover:bg-emerald-50"
          >
            <AlertCircle className="h-4 w-4" />
            Notify Contacts
          </button>
        </div>
      </div>
    </div>
  );
}